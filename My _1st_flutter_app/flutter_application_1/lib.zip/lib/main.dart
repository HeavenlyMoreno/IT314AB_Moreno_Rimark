import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

import 'Screens/student_list_screen.dart';
import 'Screens/student_details_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: '.env');
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Student Directory',
      initialRoute: '/student-list',
      onGenerateRoute: (settings) {
        if (settings.name == '/student-list') {
          return MaterialPageRoute(
            builder: (context) {
              return const StudentListScreen();
            },
          );
        }

        if (settings.name == '/student-details') {
          final student = settings.arguments as Map<String, dynamic>;

          return MaterialPageRoute(
            builder: (context) {
              return StudentDetailsScreen(
                student: student,
              );
            },
          );
        }

        return null;
      },
    );
  }
}